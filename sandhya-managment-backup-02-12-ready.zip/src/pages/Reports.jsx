import React, { useState, useEffect } from 'react';
import { db } from '../services/firebase';
import { collection, getDocs, doc, getDoc } from 'firebase/firestore';
import { FiDownload, FiTrendingUp, FiTrendingDown, FiDollarSign, FiUsers, FiBriefcase, FiCalendar, FiPieChart, FiBarChart2 } from 'react-icons/fi';
import { BarChart, Bar, LineChart, Line, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { jsPDF } from 'jspdf';
import autoTable from 'jspdf-autotable';
import Papa from 'papaparse';

const Reports = () => {
    const [stats, setStats] = useState({
        totalSales: 0,
        totalExpenses: 0,
        profit: 0,
        totalProjects: 0,
        completedProjects: 0,
        totalEmployees: 0,
        totalInterns: 0,
        totalTasks: 0
    });

    const [companySettings, setCompanySettings] = useState({
        companyName: 'Sandhya Softtech',
        companyAddress: '',
        companyPhone: '',
        companyEmail: '',
        logoUrl: ''
    });

    const [salesData, setSalesData] = useState([]);
    const [expensesData, setExpensesData] = useState([]);
    const [projectsData, setProjectsData] = useState([]);
    const [employeesData, setEmployeesData] = useState([]);
    const [internsData, setInternsData] = useState([]);
    const [attendanceData, setAttendanceData] = useState([]);
    const [loading, setLoading] = useState(true);
    const [activeTab, setActiveTab] = useState('overview');

    const COLORS = ['#F47920', '#1B5E7E', '#10B981', '#F59E0B', '#EF4444', '#8B5CF6'];

    useEffect(() => {
        fetchAllData();
    }, []);

    const fetchAllData = async () => {
        setLoading(true);
        try {
            // Fetch Company Settings
            const settingsDoc = await getDoc(doc(db, 'settings', 'company'));
            if (settingsDoc.exists()) {
                setCompanySettings(settingsDoc.data());
            }

            const [salesSnap, expensesSnap, projectsSnap, employeesSnap, internsSnap, attendanceSnap, tasksSnap] = await Promise.all([
                getDocs(collection(db, 'sales')),
                getDocs(collection(db, 'expenses')),
                getDocs(collection(db, 'projects')),
                getDocs(collection(db, 'employees')),
                getDocs(collection(db, 'interns')),
                getDocs(collection(db, 'attendance')),
                getDocs(collection(db, 'tasks'))
            ]);

            const sales = salesSnap.docs.map(doc => ({ id: doc.id, ...doc.data() }));
            const expenses = expensesSnap.docs.map(doc => ({ id: doc.id, ...doc.data() }));
            const projects = projectsSnap.docs.map(doc => ({ id: doc.id, ...doc.data() }));
            const employees = employeesSnap.docs.map(doc => ({ id: doc.id, ...doc.data() }));
            const interns = internsSnap.docs.map(doc => ({ id: doc.id, ...doc.data() }));
            const attendance = attendanceSnap.docs.map(doc => ({ id: doc.id, ...doc.data() }));

            setSalesData(sales);
            setExpensesData(expenses);
            setProjectsData(projects);
            setEmployeesData(employees);
            setInternsData(interns);
            setAttendanceData(attendance);

            const totalSales = sales.reduce((acc, doc) => acc + Number(doc.amount || 0), 0);
            const totalExpenses = expenses.reduce((acc, doc) => acc + Number(doc.amount || 0), 0);

            setStats({
                totalSales,
                totalExpenses,
                profit: totalSales - totalExpenses,
                totalProjects: projects.length,
                completedProjects: projects.filter(p => p.status === 'Completed').length,
                totalEmployees: employees.length,
                totalInterns: interns.length,
                totalTasks: tasksSnap.size
            });
        } catch (error) {
            console.error("Error fetching data:", error);
        } finally {
            setLoading(false);
        }
    };

    // Helper to load image from URL for PDF
    const getDataUri = (url) => {
        return new Promise((resolve) => {
            const img = new Image();
            img.crossOrigin = "Anonymous"; // Try to request CORS access

            const timeout = setTimeout(() => {
                console.warn("Logo load timed out (likely CORS issue)");
                resolve(null);
            }, 3000); // 3s timeout

            img.onload = function () {
                clearTimeout(timeout);
                const canvas = document.createElement('canvas');
                canvas.width = this.naturalWidth;
                canvas.height = this.naturalHeight;
                try {
                    canvas.getContext('2d').drawImage(this, 0, 0);
                    resolve(canvas.toDataURL('image/png'));
                } catch (e) {
                    console.warn("Canvas tainted (CORS issue):", e);
                    resolve(null);
                }
            };

            img.onerror = (error) => {
                clearTimeout(timeout);
                console.warn("Could not load logo for PDF:", error);
                resolve(null);
            };

            // Append a random query param to avoid cache-based CORS issues
            img.src = url + (url.includes('?') ? '&' : '?') + 't=' + new Date().getTime();
        });
    };

    const exportToPDF = async (title, data, columns) => {
        try {
            const doc = new jsPDF();
            const pageWidth = doc.internal.pageSize.width;

            // --- Professional Header Section ---

            // Add Logo if available
            let logoData = null;
            if (companySettings.logoBase64) {
                logoData = companySettings.logoBase64;
            } else if (companySettings.logoUrl) {
                logoData = await getDataUri(companySettings.logoUrl);
            }

            let logoHeight = 0;
            if (logoData) {
                try {
                    // Professional logo sizing with aspect ratio preservation
                    const logoWidth = 40;
                    const logoMaxHeight = 20;

                    // Add white background box for logo
                    doc.setFillColor(255, 255, 255);
                    doc.roundedRect(12, 8, logoWidth + 4, logoMaxHeight + 4, 2, 2, 'F');

                    // Add logo with border
                    doc.setDrawColor(230, 230, 230);
                    doc.setLineWidth(0.5);
                    doc.roundedRect(12, 8, logoWidth + 4, logoMaxHeight + 4, 2, 2, 'S');

                    // Add logo image
                    doc.addImage(logoData, 'PNG', 14, 10, logoWidth, logoMaxHeight);
                    logoHeight = logoMaxHeight + 4;
                } catch (err) {
                    console.warn("Failed to add image to PDF:", err);
                }
            }

            // Company Name & Title - Professional Header
            const headerStartY = Math.max(15, logoHeight + 5);

            doc.setFontSize(24);
            doc.setTextColor(244, 121, 32); // Primary Orange
            doc.setFont('helvetica', 'bold');
            doc.text(companySettings.companyName || 'Sandhya Softtech', pageWidth - 14, headerStartY, { align: 'right' });

            doc.setFontSize(14);
            doc.setTextColor(27, 94, 126); // Secondary Teal
            doc.setFont('helvetica', 'bold');
            doc.text(title.toUpperCase(), pageWidth - 14, headerStartY + 8, { align: 'right' });

            // Decorative line under header
            doc.setDrawColor(244, 121, 32);
            doc.setLineWidth(1);
            doc.line(14, headerStartY + 12, pageWidth - 14, headerStartY + 12);

            // Company Details - Compact and Professional
            doc.setFontSize(8);
            doc.setTextColor(80, 80, 80);
            doc.setFont('helvetica', 'normal');

            let yPos = headerStartY + 18;
            const detailsX = pageWidth - 14;

            if (companySettings.companyAddress) {
                const addressLines = doc.splitTextToSize(companySettings.companyAddress, 70);
                doc.text(addressLines, detailsX, yPos, { align: 'right' });
                yPos += (addressLines.length * 3.5);
            }

            if (companySettings.companyEmail) {
                doc.text(`Email: ${companySettings.companyEmail}`, detailsX, yPos, { align: 'right' });
                yPos += 4;
            }

            if (companySettings.companyPhone) {
                doc.text(`Phone: ${companySettings.companyPhone}`, detailsX, yPos, { align: 'right' });
                yPos += 4;
            }

            if (companySettings.companyWebsite) {
                doc.setTextColor(27, 94, 126);
                doc.text(`Web: ${companySettings.companyWebsite}`, detailsX, yPos, { align: 'right' });
            }

            // Report metadata
            const metaStartY = Math.max(yPos + 8, headerStartY + 35);
            doc.setFontSize(9);
            doc.setTextColor(100, 100, 100);
            doc.setFont('helvetica', 'italic');
            doc.text(`Generated on: ${new Date().toLocaleString()}`, 14, metaStartY);

            // Table starts after header
            const tableStartY = metaStartY + 6;

            // --- Table Section ---
            autoTable(doc, {
                startY: tableStartY,
                head: [columns],
                body: data,
                theme: 'grid',
                headStyles: {
                    fillColor: [244, 121, 32],
                    textColor: 255,
                    fontStyle: 'bold',
                    halign: 'center'
                },
                styles: {
                    fontSize: 9,
                    cellPadding: 3,
                    textColor: 50
                },
                alternateRowStyles: {
                    fillColor: [250, 245, 240]
                },
                didDrawPage: (data) => {
                    // Footer
                    const pageCount = doc.internal.getNumberOfPages();
                    doc.setFontSize(8);
                    doc.setTextColor(150, 150, 150);
                    doc.text(`Page ${pageCount}`, pageWidth / 2, doc.internal.pageSize.height - 10, { align: 'center' });
                    doc.text('Confidential Report - Internal Use Only', 14, doc.internal.pageSize.height - 10);
                }
            });

            doc.save(`${title.replace(/ /g, '_')}_${new Date().toISOString().split('T')[0]}.pdf`);
        } catch (error) {
            console.error("Error exporting PDF:", error);
            alert(`Failed to export PDF: ${error.message}`);
        }
    };

    const exportToCSV = (data, filename) => {
        try {
            const csv = Papa.unparse(data);
            const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
            const link = document.createElement('a');
            link.href = URL.createObjectURL(blob);
            link.download = `${filename}_${new Date().toISOString().split('T')[0]}.csv`;
            link.click();
        } catch (error) {
            console.error("Error exporting CSV:", error);
            alert("Failed to export CSV. Please try again.");
        }
    };

    // Chart Data Helpers
    const getSalesChartData = () => {
        const monthlyData = {};
        salesData.forEach(sale => {
            const month = sale.date ? sale.date.substring(0, 7) : 'Unknown';
            monthlyData[month] = (monthlyData[month] || 0) + Number(sale.amount || 0);
        });
        return Object.entries(monthlyData).map(([month, amount]) => ({ month, amount })).slice(-6);
    };

    const getExpensesByCategoryData = () => {
        const categoryData = {};
        expensesData.forEach(expense => {
            const category = expense.category || 'Others';
            categoryData[category] = (categoryData[category] || 0) + Number(expense.amount || 0);
        });
        return Object.entries(categoryData).map(([name, value]) => ({ name, value }));
    };

    const getProjectStatusData = () => [
        { name: 'Completed', value: stats.completedProjects },
        { name: 'In Progress', value: stats.totalProjects - stats.completedProjects }
    ];

    const getDepartmentData = () => {
        const deptData = {};
        employeesData.forEach(emp => {
            const dept = emp.department || 'Others';
            deptData[dept] = (deptData[dept] || 0) + 1;
        });
        return Object.entries(deptData).map(([name, count]) => ({ name, count }));
    };

    const getAttendanceData = () => {
        const last7Days = {};
        const today = new Date();
        for (let i = 6; i >= 0; i--) {
            const date = new Date(today);
            date.setDate(date.getDate() - i);
            const dateStr = date.toISOString().split('T')[0];
            last7Days[dateStr] = { date: dateStr, present: 0, absent: 0 };
        }
        attendanceData.forEach(record => {
            if (last7Days[record.date]) {
                if (record.status === 'Present') last7Days[record.date].present++;
                else last7Days[record.date].absent++;
            }
        });
        return Object.values(last7Days);
    };

    const StatCard = ({ title, value, icon, color, subtitle, trend }) => (
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6 hover:shadow-lg transition-all">
            <div className="flex items-center justify-between mb-3">
                <div className={`p-3 rounded-xl ${color} bg-opacity-10`}>
                    <div className={`text-2xl ${color.replace('bg-', 'text-')}`}>{icon}</div>
                </div>
                {trend && (
                    <div className={`flex items-center text-sm font-medium ${trend > 0 ? 'text-green-600' : 'text-red-600'}`}>
                        {trend > 0 ? <FiTrendingUp className="mr-1" /> : <FiTrendingDown className="mr-1" />}
                        {Math.abs(trend)}%
                    </div>
                )}
            </div>
            <h3 className="text-gray-600 text-sm font-medium mb-1">{title}</h3>
            <p className="text-3xl font-bold text-gray-800 mb-1">{value}</p>
            {subtitle && <p className="text-sm text-gray-500">{subtitle}</p>}
        </div>
    );

    if (loading) {
        return (
            <div className="flex justify-center py-12">
                <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-[#F47920]"></div>
            </div>
        );
    }

    const profitMargin = stats.totalSales > 0 ? ((stats.profit / stats.totalSales) * 100).toFixed(1) : 0;

    return (
        <div className="space-y-6">
            {/* Header */}
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 bg-white p-6 rounded-xl shadow-sm border border-gray-100">
                <div>
                    <h1 className="text-2xl font-bold text-gray-800">Reports & Analytics</h1>
                    <p className="text-gray-600 mt-1">Comprehensive business insights for {companySettings.companyName}</p>
                </div>
                <div className="flex gap-2">
                    <button
                        onClick={() => exportToCSV(salesData, 'Sales_Report')}
                        className="flex items-center px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors shadow-md text-sm font-medium"
                    >
                        <FiDownload className="mr-2" /> Export CSV
                    </button>
                    <button
                        onClick={() => exportToPDF('Complete Business Report',
                            salesData.map(s => [s.date, s.client, s.amount, s.paymentStatus]),
                            ['Date', 'Client', 'Amount', 'Status']
                        )}
                        className="flex items-center px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors shadow-md text-sm font-medium"
                    >
                        <FiDownload className="mr-2" /> Export PDF
                    </button>
                </div>
            </div>

            {/* Tabs */}
            <div className="flex gap-2 border-b border-gray-200 overflow-x-auto pb-1">
                {[
                    { key: 'overview', label: 'Overview', icon: <FiBarChart2 /> },
                    { key: 'sales', label: 'Sales', icon: <FiDollarSign /> },
                    { key: 'expenses', label: 'Expenses', icon: <FiTrendingDown /> },
                    { key: 'projects', label: 'Projects', icon: <FiBriefcase /> },
                    { key: 'attendance', label: 'Attendance', icon: <FiUsers /> },
                    { key: 'internship', label: 'Internship', icon: <FiUsers /> }
                ].map((tab) => (
                    <button
                        key={tab.key}
                        onClick={() => setActiveTab(tab.key)}
                        className={`flex items-center gap-2 px-4 py-3 font-medium transition-colors whitespace-nowrap rounded-t-lg ${activeTab === tab.key
                            ? 'bg-white text-[#F47920] border-b-2 border-[#F47920] shadow-sm'
                            : 'text-gray-600 hover:bg-gray-50'
                            }`}
                    >
                        {tab.icon}
                        {tab.label}
                    </button>
                ))}
            </div>

            {/* Overview Tab */}
            {activeTab === 'overview' && (
                <div className="space-y-6 animate-fade-in">
                    {/* Financial Stats */}
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                        <StatCard
                            title="Total Revenue"
                            value={`₹${stats.totalSales.toLocaleString()}`}
                            icon={<FiDollarSign />}
                            color="bg-green-500"
                            subtitle="Income"
                            trend={12}
                        />
                        <StatCard
                            title="Total Expenses"
                            value={`₹${stats.totalExpenses.toLocaleString()}`}
                            icon={<FiTrendingDown />}
                            color="bg-red-500"
                            subtitle="Outflow"
                        />
                        <StatCard
                            title="Net Profit"
                            value={`₹${stats.profit.toLocaleString()}`}
                            icon={<FiTrendingUp />}
                            color="bg-[#1B5E7E]"
                            subtitle={`Margin: ${profitMargin}%`}
                        />
                    </div>

                    {/* Operational Stats */}
                    <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                        <StatCard title="Projects" value={stats.totalProjects} icon={<FiBriefcase />} color="bg-blue-500"
                            subtitle={`${stats.completedProjects} completed`} />
                        <StatCard title="Employees" value={stats.totalEmployees} icon={<FiUsers />} color="bg-purple-500" />
                        <StatCard title="Interns" value={stats.totalInterns} icon={<FiUsers />} color="bg-[#F47920]" />
                        <StatCard title="Tasks" value={stats.totalTasks} icon={<FiCalendar />} color="bg-indigo-500" />
                    </div>

                    {/* Charts */}
                    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                        {/* Sales Trend */}
                        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
                            <h3 className="text-lg font-bold text-gray-800 mb-4 flex items-center gap-2">
                                <FiTrendingUp className="text-[#F47920]" /> Sales Trend (Last 6 Months)
                            </h3>
                            <ResponsiveContainer width="100%" height={300}>
                                <LineChart data={getSalesChartData()}>
                                    <CartesianGrid strokeDasharray="3 3" vertical={false} />
                                    <XAxis dataKey="month" axisLine={false} tickLine={false} />
                                    <YAxis axisLine={false} tickLine={false} />
                                    <Tooltip contentStyle={{ borderRadius: '8px', border: 'none', boxShadow: '0 4px 12px rgba(0,0,0,0.1)' }} />
                                    <Legend />
                                    <Line type="monotone" dataKey="amount" stroke="#F47920" strokeWidth={3} dot={{ r: 4 }} activeDot={{ r: 6 }} />
                                </LineChart>
                            </ResponsiveContainer>
                        </div>

                        {/* Expenses by Category */}
                        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
                            <h3 className="text-lg font-bold text-gray-800 mb-4 flex items-center gap-2">
                                <FiPieChart className="text-red-500" /> Expenses by Category
                            </h3>
                            <ResponsiveContainer width="100%" height={300}>
                                <PieChart>
                                    <Pie data={getExpensesByCategoryData()} cx="50%" cy="50%" innerRadius={60} outerRadius={100} paddingAngle={5} dataKey="value">
                                        {getExpensesByCategoryData().map((entry, index) => (
                                            <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                                        ))}
                                    </Pie>
                                    <Tooltip contentStyle={{ borderRadius: '8px', border: 'none', boxShadow: '0 4px 12px rgba(0,0,0,0.1)' }} />
                                    <Legend />
                                </PieChart>
                            </ResponsiveContainer>
                        </div>

                        {/* Department Distribution */}
                        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
                            <h3 className="text-lg font-bold text-gray-800 mb-4 flex items-center gap-2">
                                <FiUsers className="text-[#1B5E7E]" /> Employees by Department
                            </h3>
                            <ResponsiveContainer width="100%" height={300}>
                                <BarChart data={getDepartmentData()}>
                                    <CartesianGrid strokeDasharray="3 3" vertical={false} />
                                    <XAxis dataKey="name" axisLine={false} tickLine={false} />
                                    <YAxis axisLine={false} tickLine={false} />
                                    <Tooltip cursor={{ fill: 'transparent' }} contentStyle={{ borderRadius: '8px', border: 'none', boxShadow: '0 4px 12px rgba(0,0,0,0.1)' }} />
                                    <Bar dataKey="count" fill="#1B5E7E" radius={[4, 4, 0, 0]} barSize={40} />
                                </BarChart>
                            </ResponsiveContainer>
                        </div>

                        {/* Project Status */}
                        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
                            <h3 className="text-lg font-bold text-gray-800 mb-4 flex items-center gap-2">
                                <FiBriefcase className="text-blue-500" /> Project Status
                            </h3>
                            <ResponsiveContainer width="100%" height={300}>
                                <PieChart>
                                    <Pie data={getProjectStatusData()} cx="50%" cy="50%" labelLine={false}
                                        label={({ name, value }) => `${name}: ${value}`}
                                        outerRadius={100} fill="#8884d8" dataKey="value">
                                        {getProjectStatusData().map((entry, index) => (
                                            <Cell key={`cell-${index}`} fill={index === 0 ? '#10B981' : '#F59E0B'} />
                                        ))}
                                    </Pie>
                                    <Tooltip contentStyle={{ borderRadius: '8px', border: 'none', boxShadow: '0 4px 12px rgba(0,0,0,0.1)' }} />
                                </PieChart>
                            </ResponsiveContainer>
                        </div>
                    </div>
                </div>
            )}

            {/* Sales Report Tab */}
            {activeTab === 'sales' && (
                <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6 animate-fade-in">
                    <div className="flex justify-between items-center mb-6">
                        <h3 className="text-lg font-bold text-gray-800">Sales Report</h3>
                        <div className="flex gap-2">
                            <button onClick={() => exportToCSV(salesData, 'Sales_Report')} className="flex items-center px-3 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 text-sm"><FiDownload className="mr-2" /> CSV</button>
                            <button onClick={() => exportToPDF('Sales Report', salesData.map(s => [s.date || '', s.client || '', `₹${s.amount || 0}`, s.paymentStatus || '']), ['Date', 'Client', 'Amount', 'Payment Status'])} className="flex items-center px-3 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 text-sm"><FiDownload className="mr-2" /> PDF</button>
                        </div>
                    </div>
                    <div className="overflow-x-auto">
                        <table className="w-full">
                            <thead className="bg-gray-50">
                                <tr>
                                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Date</th>
                                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Client</th>
                                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Project</th>
                                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Amount</th>
                                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                                </tr>
                            </thead>
                            <tbody className="divide-y divide-gray-200">
                                {salesData.map((sale) => (
                                    <tr key={sale.id} className="hover:bg-gray-50">
                                        <td className="px-6 py-4 text-sm text-gray-900">{sale.date}</td>
                                        <td className="px-6 py-4 text-sm text-gray-900">{sale.client}</td>
                                        <td className="px-6 py-4 text-sm text-gray-600">{sale.project}</td>
                                        <td className="px-6 py-4 text-sm font-bold text-[#F47920]">₹{Number(sale.amount).toLocaleString()}</td>
                                        <td className="px-6 py-4"><span className={`px-3 py-1 rounded-full text-xs font-medium ${sale.paymentStatus === 'Paid' ? 'bg-green-100 text-green-700' : 'bg-yellow-100 text-yellow-700'}`}>{sale.paymentStatus}</span></td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                </div>
            )}

            {/* Expenses Report Tab */}
            {activeTab === 'expenses' && (
                <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6 animate-fade-in">
                    <div className="flex justify-between items-center mb-6">
                        <h3 className="text-lg font-bold text-gray-800">Expenses Report</h3>
                        <div className="flex gap-2">
                            <button onClick={() => exportToCSV(expensesData, 'Expenses_Report')} className="flex items-center px-3 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 text-sm"><FiDownload className="mr-2" /> CSV</button>
                            <button onClick={() => exportToPDF('Expenses Report', expensesData.map(e => [e.date || '', e.category || '', `₹${e.amount || 0}`, e.paidTo || '']), ['Date', 'Category', 'Amount', 'Paid To'])} className="flex items-center px-3 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 text-sm"><FiDownload className="mr-2" /> PDF</button>
                        </div>
                    </div>
                    <div className="overflow-x-auto">
                        <table className="w-full">
                            <thead className="bg-gray-50">
                                <tr>
                                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Date</th>
                                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Category</th>
                                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Amount</th>
                                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Paid To</th>
                                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Method</th>
                                </tr>
                            </thead>
                            <tbody className="divide-y divide-gray-200">
                                {expensesData.map((expense) => (
                                    <tr key={expense.id} className="hover:bg-gray-50">
                                        <td className="px-6 py-4 text-sm text-gray-900">{expense.date}</td>
                                        <td className="px-6 py-4"><span className="px-3 py-1 rounded-full text-xs font-medium bg-[#1B5E7E] bg-opacity-10 text-[#1B5E7E]">{expense.category}</span></td>
                                        <td className="px-6 py-4 text-sm font-bold text-red-600">₹{Number(expense.amount).toLocaleString()}</td>
                                        <td className="px-6 py-4 text-sm text-gray-600">{expense.paidTo}</td>
                                        <td className="px-6 py-4 text-sm text-gray-600">{expense.paymentMethod}</td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                </div>
            )}

            {/* Projects Report Tab */}
            {activeTab === 'projects' && (
                <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6 animate-fade-in">
                    <div className="flex justify-between items-center mb-6">
                        <h3 className="text-lg font-bold text-gray-800">Projects Report</h3>
                        <div className="flex gap-2">
                            <button onClick={() => exportToCSV(projectsData, 'Projects_Report')} className="flex items-center px-3 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 text-sm"><FiDownload className="mr-2" /> CSV</button>
                            <button onClick={() => exportToPDF('Projects Report', projectsData.map(p => [p.title || '', p.client || '', `${p.progress || 0}%`, p.status || '']), ['Project', 'Client', 'Progress', 'Status'])} className="flex items-center px-3 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 text-sm"><FiDownload className="mr-2" /> PDF</button>
                        </div>
                    </div>
                    <div className="overflow-x-auto">
                        <table className="w-full">
                            <thead className="bg-gray-50">
                                <tr>
                                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Project</th>
                                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Client</th>
                                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Budget</th>
                                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Progress</th>
                                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                                </tr>
                            </thead>
                            <tbody className="divide-y divide-gray-200">
                                {projectsData.map((project) => (
                                    <tr key={project.id} className="hover:bg-gray-50">
                                        <td className="px-6 py-4 text-sm font-medium text-gray-900">{project.title}</td>
                                        <td className="px-6 py-4 text-sm text-gray-600">{project.client}</td>
                                        <td className="px-6 py-4 text-sm font-bold text-[#F47920]">₹{Number(project.budget || 0).toLocaleString()}</td>
                                        <td className="px-6 py-4"><div className="flex items-center gap-2"><div className="flex-1 bg-gray-200 rounded-full h-2"><div className="bg-[#F47920] h-2 rounded-full" style={{ width: `${project.progress || 0}%` }}></div></div><span className="text-sm font-medium">{project.progress || 0}%</span></div></td>
                                        <td className="px-6 py-4"><span className={`px-3 py-1 rounded-full text-xs font-medium ${project.status === 'Completed' ? 'bg-green-100 text-green-700' : project.status === 'In Progress' ? 'bg-blue-100 text-blue-700' : 'bg-yellow-100 text-yellow-700'}`}>{project.status}</span></td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                </div>
            )}

            {/* Attendance Report Tab */}
            {activeTab === 'attendance' && (
                <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6 animate-fade-in">
                    <div className="flex justify-between items-center mb-6">
                        <h3 className="text-lg font-bold text-gray-800">Attendance Report (Last 7 Days)</h3>
                        <div className="flex gap-2">
                            <button onClick={() => exportToCSV(attendanceData, 'Attendance_Report')} className="flex items-center px-3 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 text-sm"><FiDownload className="mr-2" /> CSV</button>
                            <button onClick={() => exportToPDF('Attendance Report', attendanceData.map(a => [a.date || '', a.employeeId || '', a.status || '', a.checkIn || '', a.checkOut || '']), ['Date', 'Employee ID', 'Status', 'Check In', 'Check Out'])} className="flex items-center px-3 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 text-sm"><FiDownload className="mr-2" /> PDF</button>
                        </div>
                    </div>
                    <div className="mb-6">
                        <ResponsiveContainer width="100%" height={300}>
                            <BarChart data={getAttendanceData()}>
                                <CartesianGrid strokeDasharray="3 3" vertical={false} />
                                <XAxis dataKey="date" axisLine={false} tickLine={false} />
                                <YAxis axisLine={false} tickLine={false} />
                                <Tooltip cursor={{ fill: 'transparent' }} contentStyle={{ borderRadius: '8px', border: 'none', boxShadow: '0 4px 12px rgba(0,0,0,0.1)' }} />
                                <Bar dataKey="present" fill="#10B981" name="Present" radius={[4, 4, 0, 0]} barSize={40} />
                                <Bar dataKey="absent" fill="#EF4444" name="Absent" radius={[4, 4, 0, 0]} barSize={40} />
                            </BarChart>
                        </ResponsiveContainer>
                    </div>
                </div>
            )}

            {/* Internship Report Tab */}
            {activeTab === 'internship' && (
                <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6 animate-fade-in">
                    <div className="flex justify-between items-center mb-6">
                        <h3 className="text-lg font-bold text-gray-800">Internship Report</h3>
                        <div className="flex gap-2">
                            <button onClick={() => exportToCSV(internsData, 'Internship_Report')} className="flex items-center px-3 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 text-sm"><FiDownload className="mr-2" /> CSV</button>
                            <button onClick={() => exportToPDF('Internship Report', internsData.map(i => [i.name || '', i.college || '', i.course || '', `${i.performance || 0}%`, i.status || '']), ['Name', 'College', 'Course', 'Performance', 'Status'])} className="flex items-center px-3 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 text-sm"><FiDownload className="mr-2" /> PDF</button>
                        </div>
                    </div>
                    <div className="overflow-x-auto">
                        <table className="w-full">
                            <thead className="bg-gray-50">
                                <tr>
                                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Name</th>
                                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">College</th>
                                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Course</th>
                                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Performance</th>
                                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                                </tr>
                            </thead>
                            <tbody className="divide-y divide-gray-200">
                                {internsData.map((intern) => (
                                    <tr key={intern.id} className="hover:bg-gray-50">
                                        <td className="px-6 py-4 text-sm font-medium text-gray-900">{intern.name}</td>
                                        <td className="px-6 py-4 text-sm text-gray-600">{intern.college}</td>
                                        <td className="px-6 py-4 text-sm text-gray-600">{intern.course}</td>
                                        <td className="px-6 py-4"><div className="flex items-center gap-2"><div className="flex-1 bg-gray-200 rounded-full h-2 max-w-[100px]"><div className="bg-[#F47920] h-2 rounded-full" style={{ width: `${intern.performance || 0}%` }}></div></div><span className="text-sm font-medium">{intern.performance || 0}%</span></div></td>
                                        <td className="px-6 py-4"><span className={`px-3 py-1 rounded-full text-xs font-medium ${intern.status === 'Active' ? 'bg-green-100 text-green-700' : 'bg-blue-100 text-blue-700'}`}>{intern.status}</span></td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                </div>
            )}
        </div>
    );
};

export default Reports;
