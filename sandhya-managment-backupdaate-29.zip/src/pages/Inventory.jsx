import React, { useState, useEffect } from 'react';
import { db } from '../services/firebase';
import { collection, addDoc, getDocs, updateDoc, deleteDoc, doc, query, orderBy, serverTimestamp } from 'firebase/firestore';
import { FiPlus, FiEdit2, FiTrash2, FiBox, FiAlertTriangle, FiCheckCircle } from 'react-icons/fi';
import Modal from '../components/Modal';

const Inventory = () => {
    const [items, setItems] = useState([]);
    const [loading, setLoading] = useState(true);
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [currentItem, setCurrentItem] = useState(null);
    const [formData, setFormData] = useState({
        itemName: '',
        category: '',
        quantity: '',
        minStock: '5',
        price: '',
        supplier: ''
    });

    const fetchItems = async () => {
        setLoading(true);
        try {
            const q = query(collection(db, 'inventory'), orderBy('itemName'));
            const querySnapshot = await getDocs(q);
            const inventoryList = querySnapshot.docs.map(doc => ({
                id: doc.id,
                ...doc.data()
            }));
            setItems(inventoryList);
        } catch (error) {
            console.error("Error fetching inventory: ", error);
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        fetchItems();
    }, []);

    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setFormData(prev => ({ ...prev, [name]: value }));
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            if (currentItem) {
                const itemRef = doc(db, 'inventory', currentItem.id);
                await updateDoc(itemRef, {
                    ...formData,
                    updatedAt: serverTimestamp()
                });
            } else {
                await addDoc(collection(db, 'inventory'), {
                    ...formData,
                    createdAt: serverTimestamp()
                });
            }
            setIsModalOpen(false);
            resetForm();
            fetchItems();
        } catch (error) {
            console.error("Error saving item: ", error);
        }
    };

    const handleDelete = async (id) => {
        if (window.confirm('Are you sure you want to delete this item?')) {
            try {
                await deleteDoc(doc(db, 'inventory', id));
                fetchItems();
            } catch (error) {
                console.error("Error deleting item: ", error);
            }
        }
    };

    const openEditModal = (item) => {
        setCurrentItem(item);
        setFormData({
            itemName: item.itemName,
            category: item.category,
            quantity: item.quantity,
            minStock: item.minStock || '5',
            price: item.price,
            supplier: item.supplier
        });
        setIsModalOpen(true);
    };

    const resetForm = () => {
        setCurrentItem(null);
        setFormData({
            itemName: '',
            category: '',
            quantity: '',
            minStock: '5',
            price: '',
            supplier: ''
        });
    };

    return (
        <div className="space-y-6">
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                <h1 className="text-2xl font-bold text-gray-800">Inventory Management</h1>
                <button
                    onClick={() => { resetForm(); setIsModalOpen(true); }}
                    className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors shadow-md"
                >
                    <FiPlus className="mr-2" /> Add Item
                </button>
            </div>

            {loading ? (
                <div className="flex justify-center py-12">
                    <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
                </div>
            ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {items.map((item) => {
                        const isLowStock = Number(item.quantity) <= Number(item.minStock);
                        return (
                            <div key={item.id} className={`bg-white rounded-xl shadow-sm border p-6 hover:shadow-md transition-shadow ${isLowStock ? 'border-red-200 bg-red-50/30' : 'border-gray-100'}`}>
                                <div className="flex justify-between items-start mb-4">
                                    <div className="flex items-center gap-3">
                                        <div className={`w-10 h-10 rounded-lg flex items-center justify-center font-bold ${isLowStock ? 'bg-red-100 text-red-600' : 'bg-blue-100 text-blue-600'}`}>
                                            <FiBox />
                                        </div>
                                        <div>
                                            <h3 className="font-bold text-gray-800">{item.itemName}</h3>
                                            <p className="text-sm text-gray-500">{item.category}</p>
                                        </div>
                                    </div>
                                    <div className="flex gap-2">
                                        <button
                                            onClick={() => openEditModal(item)}
                                            className="p-2 text-gray-400 hover:text-indigo-600 hover:bg-indigo-50 rounded-lg transition-colors"
                                        >
                                            <FiEdit2 />
                                        </button>
                                        <button
                                            onClick={() => handleDelete(item.id)}
                                            className="p-2 text-gray-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                                        >
                                            <FiTrash2 />
                                        </button>
                                    </div>
                                </div>

                                <div className="flex items-center justify-between mb-4">
                                    <div className="text-center">
                                        <p className="text-xs text-gray-500 uppercase tracking-wide">Stock</p>
                                        <p className={`text-xl font-bold ${isLowStock ? 'text-red-600' : 'text-gray-800'}`}>
                                            {item.quantity}
                                        </p>
                                    </div>
                                    <div className="text-center">
                                        <p className="text-xs text-gray-500 uppercase tracking-wide">Price</p>
                                        <p className="text-xl font-bold text-gray-800">₹ {item.price}</p>
                                    </div>
                                </div>

                                {isLowStock && (
                                    <div className="flex items-center gap-2 text-red-600 text-sm bg-red-100 px-3 py-2 rounded-lg mb-3">
                                        <FiAlertTriangle />
                                        <span className="font-medium">Low Stock Alert!</span>
                                    </div>
                                )}

                                <div className="text-sm text-gray-500 pt-3 border-t border-gray-100">
                                    Supplier: <span className="font-medium text-gray-700">{item.supplier || 'N/A'}</span>
                                </div>
                            </div>
                        );
                    })}
                </div>
            )}

            <Modal
                isOpen={isModalOpen}
                onClose={() => setIsModalOpen(false)}
                title={currentItem ? "Edit Item" : "Add New Item"}
            >
                <form onSubmit={handleSubmit} className="space-y-4">
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Item Name</label>
                        <input
                            type="text"
                            name="itemName"
                            required
                            value={formData.itemName}
                            onChange={handleInputChange}
                            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                        />
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                        <div>
                            <label className="block text-sm font-medium text-gray-700 mb-1">Category</label>
                            <input
                                type="text"
                                name="category"
                                required
                                value={formData.category}
                                onChange={handleInputChange}
                                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                            />
                        </div>
                        <div>
                            <label className="block text-sm font-medium text-gray-700 mb-1">Price (₹)</label>
                            <input
                                type="number"
                                name="price"
                                required
                                value={formData.price}
                                onChange={handleInputChange}
                                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                            />
                        </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                        <div>
                            <label className="block text-sm font-medium text-gray-700 mb-1">Quantity</label>
                            <input
                                type="number"
                                name="quantity"
                                required
                                value={formData.quantity}
                                onChange={handleInputChange}
                                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                            />
                        </div>
                        <div>
                            <label className="block text-sm font-medium text-gray-700 mb-1">Min Stock Alert</label>
                            <input
                                type="number"
                                name="minStock"
                                value={formData.minStock}
                                onChange={handleInputChange}
                                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                            />
                        </div>
                    </div>

                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Supplier</label>
                        <input
                            type="text"
                            name="supplier"
                            value={formData.supplier}
                            onChange={handleInputChange}
                            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                        />
                    </div>

                    <div className="flex justify-end gap-3 mt-6">
                        <button
                            type="button"
                            onClick={() => setIsModalOpen(false)}
                            className="px-4 py-2 text-gray-700 bg-gray-100 rounded-lg hover:bg-gray-200 transition-colors"
                        >
                            Cancel
                        </button>
                        <button
                            type="submit"
                            className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
                        >
                            {currentItem ? 'Update Item' : 'Add Item'}
                        </button>
                    </div>
                </form>
            </Modal>
        </div>
    );
};

export default Inventory;
