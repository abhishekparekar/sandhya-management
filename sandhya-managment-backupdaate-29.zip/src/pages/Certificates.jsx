import React, { useState, useEffect } from 'react';
import { db } from '../services/firebase';
import { collection, addDoc, getDocs, updateDoc, deleteDoc, doc, query, orderBy, serverTimestamp } from 'firebase/firestore';
import { FiPlus, FiDownload, FiCheckCircle, FiAward, FiClock } from 'react-icons/fi';
import Modal from '../components/Modal';

const Certificates = () => {
    const [certificates, setCertificates] = useState([]);
    const [loading, setLoading] = useState(true);
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [formData, setFormData] = useState({
        recipientName: '',
        type: 'Completion', // Completion, Excellence, Participation
        courseProject: '',
        issueDate: new Date().toISOString().split('T')[0],
        status: 'Pending' // Pending, Issued
    });

    const fetchCertificates = async () => {
        setLoading(true);
        try {
            const q = query(collection(db, 'certificates'), orderBy('issueDate', 'desc'));
            const querySnapshot = await getDocs(q);
            const certList = querySnapshot.docs.map(doc => ({
                id: doc.id,
                ...doc.data()
            }));
            setCertificates(certList);
        } catch (error) {
            console.error("Error fetching certificates: ", error);
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        fetchCertificates();
    }, []);

    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setFormData(prev => ({ ...prev, [name]: value }));
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            await addDoc(collection(db, 'certificates'), {
                ...formData,
                createdAt: serverTimestamp()
            });
            setIsModalOpen(false);
            resetForm();
            fetchCertificates();
        } catch (error) {
            console.error("Error creating certificate request: ", error);
        }
    };

    const handleIssue = async (id) => {
        try {
            const certRef = doc(db, 'certificates', id);
            await updateDoc(certRef, {
                status: 'Issued',
                issuedAt: serverTimestamp()
            });
            fetchCertificates();
        } catch (error) {
            console.error("Error issuing certificate: ", error);
        }
    };

    const resetForm = () => {
        setFormData({
            recipientName: '',
            type: 'Completion',
            courseProject: '',
            issueDate: new Date().toISOString().split('T')[0],
            status: 'Pending'
        });
    };

    const downloadCertificate = (cert) => {
        alert(`Downloading ${cert.type} Certificate for ${cert.recipientName}...`);
        // In a real app, this would generate a PDF
    };

    return (
        <div className="space-y-6">
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                <h1 className="text-2xl font-bold text-gray-800">Certificates</h1>
                <button
                    onClick={() => { resetForm(); setIsModalOpen(true); }}
                    className="flex items-center px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors shadow-md"
                >
                    <FiPlus className="mr-2" /> Request Certificate
                </button>
            </div>

            {loading ? (
                <div className="flex justify-center py-12">
                    <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600"></div>
                </div>
            ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {certificates.map((cert) => (
                        <div key={cert.id} className="bg-white rounded-xl shadow-sm border border-gray-100 p-6 hover:shadow-md transition-shadow relative overflow-hidden">
                            <div className="absolute top-0 right-0 p-4 opacity-10">
                                <FiAward className="text-8xl text-indigo-600" />
                            </div>

                            <div className="relative z-10">
                                <div className="flex justify-between items-start mb-4">
                                    <span className={`px-3 py-1 rounded-full text-xs font-medium ${cert.status === 'Issued' ? 'bg-green-100 text-green-600' : 'bg-yellow-100 text-yellow-600'}`}>
                                        {cert.status}
                                    </span>
                                </div>

                                <h3 className="text-xl font-bold text-gray-800 mb-1">{cert.recipientName}</h3>
                                <p className="text-indigo-600 font-medium mb-4">{cert.type} Certificate</p>

                                <div className="space-y-2 text-sm text-gray-500 mb-6">
                                    <p>Project/Course: <span className="text-gray-700">{cert.courseProject}</span></p>
                                    <p>Date: <span className="text-gray-700">{cert.issueDate}</span></p>
                                </div>

                                <div className="flex gap-3">
                                    {cert.status === 'Pending' ? (
                                        <button
                                            onClick={() => handleIssue(cert.id)}
                                            className="flex-1 flex items-center justify-center px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors text-sm"
                                        >
                                            <FiCheckCircle className="mr-2" /> Issue Now
                                        </button>
                                    ) : (
                                        <button
                                            onClick={() => downloadCertificate(cert)}
                                            className="flex-1 flex items-center justify-center px-4 py-2 border border-indigo-600 text-indigo-600 rounded-lg hover:bg-indigo-50 transition-colors text-sm"
                                        >
                                            <FiDownload className="mr-2" /> Download
                                        </button>
                                    )}
                                </div>
                            </div>
                        </div>
                    ))}
                </div>
            )}

            <Modal
                isOpen={isModalOpen}
                onClose={() => setIsModalOpen(false)}
                title="Request New Certificate"
            >
                <form onSubmit={handleSubmit} className="space-y-4">
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Recipient Name</label>
                        <input
                            type="text"
                            name="recipientName"
                            required
                            value={formData.recipientName}
                            onChange={handleInputChange}
                            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                        />
                    </div>

                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Certificate Type</label>
                        <select
                            name="type"
                            value={formData.type}
                            onChange={handleInputChange}
                            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                        >
                            <option value="Completion">Completion</option>
                            <option value="Excellence">Excellence</option>
                            <option value="Participation">Participation</option>
                            <option value="Internship">Internship</option>
                        </select>
                    </div>

                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Course / Project Name</label>
                        <input
                            type="text"
                            name="courseProject"
                            required
                            value={formData.courseProject}
                            onChange={handleInputChange}
                            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                        />
                    </div>

                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Issue Date</label>
                        <input
                            type="date"
                            name="issueDate"
                            required
                            value={formData.issueDate}
                            onChange={handleInputChange}
                            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                        />
                    </div>

                    <div className="flex justify-end gap-3 mt-6">
                        <button
                            type="button"
                            onClick={() => setIsModalOpen(false)}
                            className="px-4 py-2 text-gray-700 bg-gray-100 rounded-lg hover:bg-gray-200 transition-colors"
                        >
                            Cancel
                        </button>
                        <button
                            type="submit"
                            className="px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors"
                        >
                            Request Certificate
                        </button>
                    </div>
                </form>
            </Modal>
        </div>
    );
};

export default Certificates;
