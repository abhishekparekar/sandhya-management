import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { FiUser, FiMail, FiBell, FiLock, FiGlobe, FiSave } from 'react-icons/fi';

const Settings = () => {
    const { currentUser } = useAuth();
    const [settings, setSettings] = useState({
        // Profile Settings
        displayName: currentUser?.displayName || '',
        email: currentUser?.email || '',
        phone: '',

        // Notification Settings
        emailNotifications: true,
        pushNotifications: true,
        weeklyReports: false,

        // Appearance Settings
        theme: 'light',
        language: 'en',

        // Security Settings
        twoFactorAuth: false,
        sessionTimeout: '30'
    });

    const [saved, setSaved] = useState(false);

    const handleSave = (e) => {
        e.preventDefault();
        // Here you would typically save to Firebase
        console.log('Saving settings:', settings);
        setSaved(true);
        setTimeout(() => setSaved(false), 3000);
    };

    const SettingSection = ({ title, icon, children }) => (
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
            <div className="flex items-center gap-3 mb-6">
                <div className="p-2 bg-indigo-100 rounded-lg text-indigo-600">
                    {icon}
                </div>
                <h2 className="text-xl font-bold text-gray-800">{title}</h2>
            </div>
            {children}
        </div>
    );

    const ToggleSwitch = ({ label, checked, onChange }) => (
        <div className="flex items-center justify-between py-3">
            <span className="text-gray-700">{label}</span>
            <button
                type="button"
                onClick={() => onChange(!checked)}
                className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${checked ? 'bg-indigo-600' : 'bg-gray-300'
                    }`}
            >
                <span
                    className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${checked ? 'translate-x-6' : 'translate-x-1'
                        }`}
                />
            </button>
        </div>
    );

    return (
        <div className="space-y-6">
            <div>
                <h1 className="text-2xl font-bold text-gray-800">Settings</h1>
                <p className="text-gray-600 mt-1">Manage your account and application preferences</p>
            </div>

            {saved && (
                <div className="bg-green-50 border border-green-200 text-green-700 px-4 py-3 rounded-lg flex items-center">
                    <FiSave className="mr-2" />
                    Settings saved successfully!
                </div>
            )}

            <form onSubmit={handleSave} className="space-y-6">
                {/* Profile Settings */}
                <SettingSection title="Profile Information" icon={<FiUser />}>
                    <div className="space-y-4">
                        <div>
                            <label className="block text-sm font-medium text-gray-700 mb-1">Display Name</label>
                            <input
                                type="text"
                                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                                value={settings.displayName}
                                onChange={(e) => setSettings({ ...settings, displayName: e.target.value })}
                            />
                        </div>
                        <div>
                            <label className="block text-sm font-medium text-gray-700 mb-1">Email</label>
                            <input
                                type="email"
                                className="w-full px-3 py-2 border border-gray-300 rounded-lg bg-gray-50"
                                value={settings.email}
                                disabled
                            />
                            <p className="text-xs text-gray-500 mt-1">Email cannot be changed</p>
                        </div>
                        <div>
                            <label className="block text-sm font-medium text-gray-700 mb-1">Phone Number</label>
                            <input
                                type="tel"
                                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                                value={settings.phone}
                                onChange={(e) => setSettings({ ...settings, phone: e.target.value })}
                                placeholder="+91 XXXXX XXXXX"
                            />
                        </div>
                    </div>
                </SettingSection>

                {/* Notification Settings */}
                <SettingSection title="Notifications" icon={<FiBell />}>
                    <div className="divide-y divide-gray-200">
                        <ToggleSwitch
                            label="Email Notifications"
                            checked={settings.emailNotifications}
                            onChange={(val) => setSettings({ ...settings, emailNotifications: val })}
                        />
                        <ToggleSwitch
                            label="Push Notifications"
                            checked={settings.pushNotifications}
                            onChange={(val) => setSettings({ ...settings, pushNotifications: val })}
                        />
                        <ToggleSwitch
                            label="Weekly Reports"
                            checked={settings.weeklyReports}
                            onChange={(val) => setSettings({ ...settings, weeklyReports: val })}
                        />
                    </div>
                </SettingSection>

                {/* Appearance Settings */}
                <SettingSection title="Appearance" icon={<FiGlobe />}>
                    <div className="space-y-4">
                        <div>
                            <label className="block text-sm font-medium text-gray-700 mb-2">Theme</label>
                            <div className="grid grid-cols-2 gap-3">
                                {['light', 'dark'].map((theme) => (
                                    <button
                                        key={theme}
                                        type="button"
                                        onClick={() => setSettings({ ...settings, theme })}
                                        className={`px-4 py-3 rounded-lg border-2 transition-all capitalize ${settings.theme === theme
                                                ? 'border-indigo-600 bg-indigo-50 text-indigo-700'
                                                : 'border-gray-200 hover:border-gray-300'
                                            }`}
                                    >
                                        {theme}
                                    </button>
                                ))}
                            </div>
                        </div>
                        <div>
                            <label className="block text-sm font-medium text-gray-700 mb-1">Language</label>
                            <select
                                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                                value={settings.language}
                                onChange={(e) => setSettings({ ...settings, language: e.target.value })}
                            >
                                <option value="en">English</option>
                                <option value="hi">Hindi</option>
                                <option value="mr">Marathi</option>
                            </select>
                        </div>
                    </div>
                </SettingSection>

                {/* Security Settings */}
                <SettingSection title="Security" icon={<FiLock />}>
                    <div className="space-y-4">
                        <ToggleSwitch
                            label="Two-Factor Authentication"
                            checked={settings.twoFactorAuth}
                            onChange={(val) => setSettings({ ...settings, twoFactorAuth: val })}
                        />
                        <div>
                            <label className="block text-sm font-medium text-gray-700 mb-1">Session Timeout (minutes)</label>
                            <select
                                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                                value={settings.sessionTimeout}
                                onChange={(e) => setSettings({ ...settings, sessionTimeout: e.target.value })}
                            >
                                <option value="15">15 minutes</option>
                                <option value="30">30 minutes</option>
                                <option value="60">1 hour</option>
                                <option value="120">2 hours</option>
                            </select>
                        </div>
                        <button
                            type="button"
                            className="w-full px-4 py-2 bg-red-50 text-red-600 rounded-lg hover:bg-red-100 transition-colors font-medium"
                        >
                            Change Password
                        </button>
                    </div>
                </SettingSection>

                {/* Save Button */}
                <div className="flex justify-end gap-3">
                    <button
                        type="button"
                        className="px-6 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
                    >
                        Cancel
                    </button>
                    <button
                        type="submit"
                        className="px-6 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors flex items-center shadow-md"
                    >
                        <FiSave className="mr-2" /> Save Changes
                    </button>
                </div>
            </form>
        </div>
    );
};

export default Settings;
