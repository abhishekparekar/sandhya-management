import React, { useState, useEffect } from 'react';
import { db } from '../services/firebase';
import { collection, getDocs } from 'firebase/firestore';
import {
    FiUsers, FiBriefcase, FiDollarSign, FiTrendingUp, FiActivity,
    FiPhone, FiBox, FiFileText, FiCheckCircle, FiClock
} from 'react-icons/fi';

const Dashboard = () => {
    const [stats, setStats] = useState({
        projects: { total: 0, android: 0, web: 0 },
        sales: { today: 0, thisMonth: 0, total: 0 },
        telecalling: { interested: 0, followUp: 0, notInterested: 0 },
        expenses: { total: 0, thisMonth: 0 },
        inventory: { total: 0, lowStock: 0 },
        employees: { total: 0 },
        interns: { total: 0, active: 0 },
        tasks: { total: 0, pending: 0, completed: 0 }
    });
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        fetchDashboardData();
    }, []);

    const fetchDashboardData = async () => {
        try {
            const projectsSnap = await getDocs(collection(db, 'projects'));
            const projects = projectsSnap.docs.map(doc => doc.data());
            const androidProjects = projects.filter(p => p.type?.toLowerCase() === 'android').length;
            const webProjects = projects.filter(p => p.type?.toLowerCase() === 'web').length;

            const salesSnap = await getDocs(collection(db, 'sales'));
            const sales = salesSnap.docs.map(doc => doc.data());
            const totalSales = sales.reduce((acc, sale) => acc + Number(sale.amount || 0), 0);

            const today = new Date().toISOString().split('T')[0];
            const salesToday = sales.filter(s => s.date === today).reduce((acc, s) => acc + Number(s.amount || 0), 0);

            const thisMonth = new Date().getMonth();
            const salesThisMonth = sales.filter(s => {
                const saleDate = new Date(s.date);
                return saleDate.getMonth() === thisMonth;
            }).reduce((acc, s) => acc + Number(s.amount || 0), 0);

            const leadsSnap = await getDocs(collection(db, 'leads'));
            const leads = leadsSnap.docs.map(doc => doc.data());
            const interested = leads.filter(l => l.status === 'Interested').length;
            const followUp = leads.filter(l => l.status === 'Follow-up').length;
            const notInterested = leads.filter(l => l.status === 'Not Interested').length;

            const expensesSnap = await getDocs(collection(db, 'expenses'));
            const expenses = expensesSnap.docs.map(doc => doc.data());
            const totalExpenses = expenses.reduce((acc, exp) => acc + Number(exp.amount || 0), 0);
            const expensesThisMonth = expenses.filter(e => {
                const expDate = new Date(e.date);
                return expDate.getMonth() === thisMonth;
            }).reduce((acc, e) => acc + Number(e.amount || 0), 0);

            const inventorySnap = await getDocs(collection(db, 'inventory'));
            const inventory = inventorySnap.docs.map(doc => doc.data());
            const lowStock = inventory.filter(i => Number(i.quantity || 0) < 10).length;

            const employeesSnap = await getDocs(collection(db, 'employees'));

            const internsSnap = await getDocs(collection(db, 'interns'));
            const interns = internsSnap.docs.map(doc => doc.data());
            const activeInterns = interns.filter(i => i.status === 'Active').length;

            const tasksSnap = await getDocs(collection(db, 'tasks'));
            const tasks = tasksSnap.docs.map(doc => doc.data());
            const pendingTasks = tasks.filter(t => t.status === 'Pending').length;
            const completedTasks = tasks.filter(t => t.status === 'Completed').length;

            setStats({
                projects: { total: projectsSnap.size, android: androidProjects, web: webProjects },
                sales: { today: salesToday, thisMonth: salesThisMonth, total: totalSales },
                telecalling: { interested, followUp, notInterested },
                expenses: { total: totalExpenses, thisMonth: expensesThisMonth },
                inventory: { total: inventorySnap.size, lowStock },
                employees: { total: employeesSnap.size },
                interns: { total: internsSnap.size, active: activeInterns },
                tasks: { total: tasksSnap.size, pending: pendingTasks, completed: completedTasks }
            });
        } catch (error) {
            console.error("Error fetching dashboard data:", error);
        } finally {
            setLoading(false);
        }
    };

    const StatCard = ({ title, value, subtitle, icon, color, trend }) => (
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6 hover:shadow-lg transition-all">
            <div className="flex items-center justify-between mb-3">
                <div className={`p-3 rounded-xl ${color} bg-opacity-10`}>
                    <div className={`text-2xl ${color.replace('bg-', 'text-')}`}>{icon}</div>
                </div>
                {trend && (
                    <span className="flex items-center text-sm font-medium text-green-500 bg-green-50 px-2 py-1 rounded-full">
                        <FiTrendingUp className="mr-1" /> {trend}
                    </span>
                )}
            </div>
            <h3 className="text-gray-600 text-sm font-medium mb-1">{title}</h3>
            <p className="text-3xl font-bold text-gray-800 mb-1">{value}</p>
            {subtitle && <p className="text-sm text-gray-500">{subtitle}</p>}
        </div>
    );

    const BarChart = ({ data, title, color = 'bg-[#1B5E7E]' }) => {
        const maxValue = Math.max(...data.map(d => d.value), 1);

        return (
            <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
                <h3 className="text-lg font-bold text-gray-800 mb-6">{title}</h3>
                <div className="space-y-4">
                    {data.map((item, index) => (
                        <div key={index}>
                            <div className="flex justify-between mb-2">
                                <span className="text-sm font-medium text-gray-700">{item.label}</span>
                                <span className="text-sm font-bold text-gray-800">{item.value}</span>
                            </div>
                            <div className="w-full bg-gray-200 rounded-full h-3">
                                <div
                                    className={`h-3 rounded-full ${color} transition-all duration-500`}
                                    style={{ width: `${(item.value / maxValue) * 100}%` }}
                                ></div>
                            </div>
                        </div>
                    ))}
                </div>
            </div>
        );
    };

    if (loading) {
        return (
            <div className="flex justify-center items-center h-96">
                <div className="animate-spin rounded-full h-16 w-16 border-b-4 border-[#F47920]"></div>
            </div>
        );
    }

    return (
        <div className="space-y-6">
            {/* Header */}


            {/* Quick Stats Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                <StatCard
                    title="Total Projects"
                    value={stats.projects.total}
                    subtitle={`${stats.projects.android} Android, ${stats.projects.web} Web`}
                    icon={<FiBriefcase />}
                    color="bg-[#1B5E7E]"
                />
                <StatCard
                    title="Sales This Month"
                    value={`₹${stats.sales.thisMonth.toLocaleString()}`}
                    subtitle={`Today: ₹${stats.sales.today.toLocaleString()}`}
                    icon={<FiDollarSign />}
                    color="bg-[#F47920]"
                    trend="+12%"
                />
                <StatCard
                    title="Total Employees"
                    value={stats.employees.total}
                    subtitle={`${stats.interns.active} Active Interns`}
                    icon={<FiUsers />}
                    color="bg-[#1B5E7E]"
                />
                <StatCard
                    title="Pending Tasks"
                    value={stats.tasks.pending}
                    subtitle={`${stats.tasks.completed} Completed`}
                    icon={<FiCheckCircle />}
                    color="bg-[#F47920]"
                />
            </div>

            {/* Charts Section */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <BarChart
                    title="Projects by Type"
                    color="bg-[#1B5E7E]"
                    data={[
                        { label: 'Android Projects', value: stats.projects.android },
                        { label: 'Web Projects', value: stats.projects.web },
                        { label: 'Total Projects', value: stats.projects.total }
                    ]}
                />

                <BarChart
                    title="Telecalling Status"
                    color="bg-[#F47920]"
                    data={[
                        { label: 'Interested', value: stats.telecalling.interested },
                        { label: 'Follow-up Required', value: stats.telecalling.followUp },
                        { label: 'Not Interested', value: stats.telecalling.notInterested }
                    ]}
                />

                <BarChart
                    title="Financial Overview (This Month)"
                    color="bg-[#1B5E7E]"
                    data={[
                        { label: 'Sales', value: stats.sales.thisMonth },
                        { label: 'Expenses', value: stats.expenses.thisMonth },
                        { label: 'Profit', value: stats.sales.thisMonth - stats.expenses.thisMonth }
                    ]}
                />

                <BarChart
                    title="Team Overview"
                    color="bg-[#F47920]"
                    data={[
                        { label: 'Employees', value: stats.employees.total },
                        { label: 'Active Interns', value: stats.interns.active },
                        { label: 'Total Team', value: stats.employees.total + stats.interns.total }
                    ]}
                />
            </div>

            {/* Detailed Stats */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
                    <div className="flex items-center gap-3 mb-4">
                        <div className="p-2 bg-[#1B5E7E] bg-opacity-10 rounded-lg">
                            <FiBox className="text-[#1B5E7E] text-xl" />
                        </div>
                        <h3 className="text-lg font-bold text-gray-800">Inventory Overview</h3>
                    </div>
                    <div className="space-y-3">
                        <div className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                            <span className="text-gray-600">Total Items</span>
                            <span className="font-bold text-gray-800">{stats.inventory.total}</span>
                        </div>
                        <div className="flex justify-between items-center p-3 bg-red-50 rounded-lg">
                            <span className="text-red-600">Low Stock Items</span>
                            <span className="font-bold text-red-700">{stats.inventory.lowStock}</span>
                        </div>
                    </div>
                </div>

                <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
                    <div className="flex items-center gap-3 mb-4">
                        <div className="p-2 bg-red-100 rounded-lg">
                            <FiFileText className="text-red-600 text-xl" />
                        </div>
                        <h3 className="text-lg font-bold text-gray-800">Expenses</h3>
                    </div>
                    <div className="space-y-3">
                        <div className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                            <span className="text-gray-600">This Month</span>
                            <span className="font-bold text-gray-800">₹{stats.expenses.thisMonth.toLocaleString()}</span>
                        </div>
                        <div className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                            <span className="text-gray-600">Total</span>
                            <span className="font-bold text-gray-800">₹{stats.expenses.total.toLocaleString()}</span>
                        </div>
                    </div>
                </div>

                <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
                    <div className="flex items-center gap-3 mb-4">
                        <div className="p-2 bg-[#F47920] bg-opacity-10 rounded-lg">
                            <FiClock className="text-[#F47920] text-xl" />
                        </div>
                        <h3 className="text-lg font-bold text-gray-800">Today's Summary</h3>
                    </div>
                    <div className="space-y-3">
                        <div className="flex justify-between items-center p-3 bg-green-50 rounded-lg">
                            <span className="text-gray-600">Sales Today</span>
                            <span className="font-bold text-green-700">₹{stats.sales.today.toLocaleString()}</span>
                        </div>
                        <div className="flex justify-between items-center p-3 bg-orange-50 rounded-lg">
                            <span className="text-gray-600">Pending Tasks</span>
                            <span className="font-bold text-orange-700">{stats.tasks.pending}</span>
                        </div>
                    </div>
                </div>
            </div>

            {/* Task Status */}
            <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
                <h3 className="text-lg font-bold text-gray-800 mb-6">Task Status Overview</h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="p-4 bg-orange-50 rounded-lg border-l-4 border-[#F47920]">
                        <p className="text-sm text-gray-600 mb-1">Pending Tasks</p>
                        <p className="text-3xl font-bold text-[#F47920]">{stats.tasks.pending}</p>
                    </div>
                    <div className="p-4 bg-green-50 rounded-lg border-l-4 border-green-500">
                        <p className="text-sm text-gray-600 mb-1">Completed Tasks</p>
                        <p className="text-3xl font-bold text-green-600">{stats.tasks.completed}</p>
                    </div>
                    <div className="p-4 bg-blue-50 rounded-lg border-l-4 border-[#1B5E7E]">
                        <p className="text-sm text-gray-600 mb-1">Total Tasks</p>
                        <p className="text-3xl font-bold text-[#1B5E7E]">{stats.tasks.total}</p>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default Dashboard;
