import React, { useState, useEffect, useRef } from 'react';
import { db } from '../services/firebase';
import { collection, getDocs, query, orderBy } from 'firebase/firestore';
import { FiPrinter, FiUser } from 'react-icons/fi';
import { useReactToPrint } from 'react-to-print';

const IDCard = ({ employee }) => (
    <div className="w-[350px] h-[500px] bg-white rounded-xl shadow-2xl overflow-hidden relative border border-gray-200 flex flex-col items-center text-center font-sans print:shadow-none print:border-0">
        <div className="absolute top-0 w-full h-32 bg-indigo-900"></div>
        <div className="absolute top-24 w-32 h-32 rounded-full border-4 border-white bg-gray-200 flex items-center justify-center overflow-hidden z-10">
            {employee.photoURL ? (
                <img src={employee.photoURL} alt={employee.name} className="w-full h-full object-cover" />
            ) : (
                <FiUser className="text-6xl text-gray-400" />
            )}
        </div>

        <div className="mt-60 px-6 w-full">
            <h2 className="text-2xl font-bold text-gray-800">{employee.name}</h2>
            <p className="text-indigo-600 font-medium text-lg mb-6">{employee.role}</p>

            <div className="space-y-3 text-left bg-gray-50 p-4 rounded-lg text-sm">
                <div className="flex justify-between">
                    <span className="text-gray-500">ID No:</span>
                    <span className="font-semibold text-gray-800">EMP-{employee.id.substring(0, 6).toUpperCase()}</span>
                </div>
                <div className="flex justify-between">
                    <span className="text-gray-500">Phone:</span>
                    <span className="font-semibold text-gray-800">{employee.phone}</span>
                </div>
                <div className="flex justify-between">
                    <span className="text-gray-500">Email:</span>
                    <span className="font-semibold text-gray-800 truncate max-w-[150px]">{employee.email}</span>
                </div>
            </div>
        </div>

        <div className="mt-auto mb-8 w-full px-6">
            <div className="border-t border-gray-300 pt-4">
                <p className="text-xs text-gray-400">Sandhya Management System</p>
                <p className="text-[10px] text-gray-300 mt-1">Authorized Signature</p>
            </div>
        </div>
    </div>
);

const IDCards = () => {
    const [employees, setEmployees] = useState([]);
    const [selectedEmployee, setSelectedEmployee] = useState(null);
    const [loading, setLoading] = useState(true);
    const componentRef = useRef();

    const handlePrint = useReactToPrint({
        content: () => componentRef.current,
    });

    useEffect(() => {
        const fetchEmployees = async () => {
            try {
                const q = query(collection(db, 'employees'), orderBy('name'));
                const querySnapshot = await getDocs(q);
                const empList = querySnapshot.docs.map(doc => ({
                    id: doc.id,
                    ...doc.data()
                }));
                setEmployees(empList);
                if (empList.length > 0) setSelectedEmployee(empList[0]);
            } catch (error) {
                console.error("Error fetching employees: ", error);
            } finally {
                setLoading(false);
            }
        };
        fetchEmployees();
    }, []);

    return (
        <div className="space-y-6">
            <h1 className="text-2xl font-bold text-gray-800">ID Card Generation</h1>

            {loading ? (
                <div className="flex justify-center py-12">
                    <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600"></div>
                </div>
            ) : (
                <div className="flex flex-col lg:flex-row gap-8">
                    {/* Sidebar: Employee List */}
                    <div className="w-full lg:w-1/3 bg-white rounded-xl shadow-sm border border-gray-100 p-4 h-[600px] overflow-y-auto">
                        <h3 className="font-bold text-gray-700 mb-4 px-2">Select Employee</h3>
                        <div className="space-y-2">
                            {employees.map(emp => (
                                <button
                                    key={emp.id}
                                    onClick={() => setSelectedEmployee(emp)}
                                    className={`w-full text-left p-3 rounded-lg transition-colors flex items-center gap-3 ${selectedEmployee?.id === emp.id
                                            ? 'bg-indigo-50 text-indigo-700 border border-indigo-200'
                                            : 'hover:bg-gray-50 text-gray-600'
                                        }`}
                                >
                                    <div className="w-8 h-8 rounded-full bg-indigo-100 flex items-center justify-center text-indigo-600 font-bold text-xs">
                                        {emp.name.charAt(0).toUpperCase()}
                                    </div>
                                    <div>
                                        <p className="font-medium text-sm">{emp.name}</p>
                                        <p className="text-xs opacity-70">{emp.role}</p>
                                    </div>
                                </button>
                            ))}
                        </div>
                    </div>

                    {/* Preview Area */}
                    <div className="flex-1 bg-gray-100 rounded-xl border border-gray-200 p-8 flex flex-col items-center justify-center">
                        {selectedEmployee ? (
                            <>
                                <div className="mb-8 transform scale-100 origin-top">
                                    <div ref={componentRef}>
                                        <IDCard employee={selectedEmployee} />
                                    </div>
                                </div>
                                <button
                                    onClick={handlePrint}
                                    className="flex items-center px-6 py-3 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors shadow-lg font-medium"
                                >
                                    <FiPrinter className="mr-2" /> Print ID Card
                                </button>
                            </>
                        ) : (
                            <p className="text-gray-500">Select an employee to generate ID card</p>
                        )}
                    </div>
                </div>
            )}
        </div>
    );
};

export default IDCards;
