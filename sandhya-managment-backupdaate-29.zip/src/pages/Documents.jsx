import React, { useState, useEffect } from 'react';
import { db, storage } from '../services/firebase';
import { collection, addDoc, getDocs, deleteDoc, doc, query, orderBy, serverTimestamp } from 'firebase/firestore';
import { ref, uploadBytes, getDownloadURL, deleteObject } from 'firebase/storage';
import { FiUpload, FiTrash2, FiFileText, FiDownload, FiImage, FiFile } from 'react-icons/fi';
import Modal from '../components/Modal';

const Documents = () => {
    const [documents, setDocuments] = useState([]);
    const [loading, setLoading] = useState(true);
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [uploading, setUploading] = useState(false);
    const [file, setFile] = useState(null);
    const [fileName, setFileName] = useState('');

    const fetchDocuments = async () => {
        setLoading(true);
        try {
            const q = query(collection(db, 'documents'), orderBy('createdAt', 'desc'));
            const querySnapshot = await getDocs(q);
            const docList = querySnapshot.docs.map(doc => ({
                id: doc.id,
                ...doc.data()
            }));
            setDocuments(docList);
        } catch (error) {
            console.error("Error fetching documents: ", error);
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        fetchDocuments();
    }, []);

    const handleFileChange = (e) => {
        if (e.target.files[0]) {
            setFile(e.target.files[0]);
            setFileName(e.target.files[0].name);
        }
    };

    const handleUpload = async (e) => {
        e.preventDefault();
        if (!file) return;

        setUploading(true);
        try {
            const storageRef = ref(storage, `documents/${Date.now()}_${file.name}`);
            const snapshot = await uploadBytes(storageRef, file);
            const downloadURL = await getDownloadURL(snapshot.ref);

            await addDoc(collection(db, 'documents'), {
                name: fileName,
                url: downloadURL,
                type: file.type,
                size: file.size,
                path: snapshot.ref.fullPath,
                createdAt: serverTimestamp()
            });

            setIsModalOpen(false);
            setFile(null);
            setFileName('');
            fetchDocuments();
        } catch (error) {
            console.error("Error uploading document: ", error);
        } finally {
            setUploading(false);
        }
    };

    const handleDelete = async (docData) => {
        if (window.confirm('Are you sure you want to delete this file?')) {
            try {
                // Delete from Storage
                const fileRef = ref(storage, docData.path);
                await deleteObject(fileRef);

                // Delete from Firestore
                await deleteDoc(doc(db, 'documents', docData.id));
                fetchDocuments();
            } catch (error) {
                console.error("Error deleting document: ", error);
            }
        }
    };

    const formatSize = (bytes) => {
        if (bytes === 0) return '0 Bytes';
        const k = 1024;
        const sizes = ['Bytes', 'KB', 'MB', 'GB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
    };

    const getFileIcon = (type) => {
        if (type.includes('image')) return <FiImage className="text-purple-500" />;
        if (type.includes('pdf')) return <FiFileText className="text-red-500" />;
        return <FiFile className="text-gray-500" />;
    };

    return (
        <div className="space-y-6">
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                <h1 className="text-2xl font-bold text-gray-800">Document Storage</h1>
                <button
                    onClick={() => setIsModalOpen(true)}
                    className="flex items-center px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors shadow-md"
                >
                    <FiUpload className="mr-2" /> Upload File
                </button>
            </div>

            {loading ? (
                <div className="flex justify-center py-12">
                    <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600"></div>
                </div>
            ) : (
                <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
                    <ul className="divide-y divide-gray-100">
                        {documents.map((doc) => (
                            <li key={doc.id} className="p-4 hover:bg-gray-50 transition-colors flex items-center justify-between">
                                <div className="flex items-center gap-4">
                                    <div className="p-3 bg-gray-100 rounded-lg text-xl">
                                        {getFileIcon(doc.type)}
                                    </div>
                                    <div>
                                        <h3 className="font-medium text-gray-800">{doc.name}</h3>
                                        <p className="text-xs text-gray-500">
                                            {formatSize(doc.size)} • {new Date(doc.createdAt?.seconds * 1000).toLocaleDateString()}
                                        </p>
                                    </div>
                                </div>
                                <div className="flex gap-2">
                                    <a
                                        href={doc.url}
                                        target="_blank"
                                        rel="noopener noreferrer"
                                        className="p-2 text-gray-400 hover:text-indigo-600 hover:bg-indigo-50 rounded-lg transition-colors"
                                        title="Download/View"
                                    >
                                        <FiDownload />
                                    </a>
                                    <button
                                        onClick={() => handleDelete(doc)}
                                        className="p-2 text-gray-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                                        title="Delete"
                                    >
                                        <FiTrash2 />
                                    </button>
                                </div>
                            </li>
                        ))}
                        {documents.length === 0 && (
                            <li className="p-8 text-center text-gray-500">
                                No documents uploaded yet.
                            </li>
                        )}
                    </ul>
                </div>
            )}

            <Modal
                isOpen={isModalOpen}
                onClose={() => setIsModalOpen(false)}
                title="Upload Document"
            >
                <form onSubmit={handleUpload} className="space-y-4">
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">File Name (Optional)</label>
                        <input
                            type="text"
                            value={fileName}
                            onChange={(e) => setFileName(e.target.value)}
                            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                            placeholder="Custom name for the file"
                        />
                    </div>

                    <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center hover:border-indigo-500 transition-colors">
                        <input
                            type="file"
                            onChange={handleFileChange}
                            className="hidden"
                            id="file-upload"
                        />
                        <label htmlFor="file-upload" className="cursor-pointer flex flex-col items-center">
                            <FiUpload className="text-3xl text-gray-400 mb-2" />
                            <span className="text-sm text-gray-600">Click to select a file</span>
                            {file && <span className="mt-2 text-sm font-medium text-indigo-600">{file.name}</span>}
                        </label>
                    </div>

                    <div className="flex justify-end gap-3 mt-6">
                        <button
                            type="button"
                            onClick={() => setIsModalOpen(false)}
                            className="px-4 py-2 text-gray-700 bg-gray-100 rounded-lg hover:bg-gray-200 transition-colors"
                        >
                            Cancel
                        </button>
                        <button
                            type="submit"
                            disabled={!file || uploading}
                            className="px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors disabled:opacity-50"
                        >
                            {uploading ? 'Uploading...' : 'Upload'}
                        </button>
                    </div>
                </form>
            </Modal>
        </div>
    );
};

export default Documents;
