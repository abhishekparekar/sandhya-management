import React, { useState, useEffect } from 'react';
import { db } from '../services/firebase';
import { collection, getDocs } from 'firebase/firestore';
import { FiTrendingUp, FiUsers, FiBriefcase, FiDollarSign, FiCheckCircle, FiClock } from 'react-icons/fi';

const Progress = () => {
    const [progressData, setProgressData] = useState({
        projects: { total: 0, completed: 0, inProgress: 0, pending: 0 },
        sales: { total: 0, thisMonth: 0, lastMonth: 0 },
        employees: { total: 0, active: 0 },
        tasks: { total: 0, completed: 0, pending: 0 }
    });
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        fetchProgressData();
    }, []);

    const fetchProgressData = async () => {
        try {
            const projectsSnap = await getDocs(collection(db, 'projects'));
            const salesSnap = await getDocs(collection(db, 'sales'));
            const employeesSnap = await getDocs(collection(db, 'employees'));

            const projects = projectsSnap.docs.map(doc => doc.data());
            const completedProjects = projects.filter(p => p.status === 'Completed').length;
            const inProgressProjects = projects.filter(p => p.status === 'In Progress').length;
            const pendingProjects = projects.filter(p => p.status === 'Pending').length;

            const sales = salesSnap.docs.map(doc => doc.data());
            const totalSales = sales.reduce((acc, sale) => acc + Number(sale.amount || 0), 0);

            setProgressData({
                projects: {
                    total: projectsSnap.size,
                    completed: completedProjects,
                    inProgress: inProgressProjects,
                    pending: pendingProjects
                },
                sales: {
                    total: totalSales,
                    thisMonth: totalSales,
                    lastMonth: 0
                },
                employees: {
                    total: employeesSnap.size,
                    active: employeesSnap.size
                },
                tasks: {
                    total: 45,
                    completed: 32,
                    pending: 13
                }
            });
        } catch (error) {
            console.error("Error fetching progress data:", error);
        } finally {
            setLoading(false);
        }
    };

    const ProgressCard = ({ title, value, total, icon, color, percentage }) => (
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6 hover:shadow-lg transition-all">
            <div className="flex items-center justify-between mb-4">
                <div className={`p-3 rounded-xl ${color} bg-opacity-10`}>
                    <div className={`text-2xl ${color.replace('bg-', 'text-')}`}>{icon}</div>
                </div>
                <span className="text-2xl font-bold text-gray-800">{percentage}%</span>
            </div>
            <h3 className="text-gray-600 text-sm font-medium mb-2">{title}</h3>
            <div className="flex items-baseline gap-2 mb-3">
                <span className="text-3xl font-bold text-gray-800">{value}</span>
                <span className="text-gray-500">/ {total}</span>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-2">
                <div
                    className={`h-2 rounded-full ${color} transition-all`}
                    style={{ width: `${percentage}%` }}
                ></div>
            </div>
        </div>
    );

    return (
        <div className="space-y-6">
            <div>
                <h1 className="text-2xl font-bold text-gray-800">Progress Tracking</h1>
                <p className="text-gray-600 mt-1">Monitor overall business progress and metrics</p>
            </div>

            {loading ? (
                <div className="flex justify-center py-12">
                    <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600"></div>
                </div>
            ) : (
                <>
                    {/* Overview Cards */}
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                        <ProgressCard
                            title="Projects Completed"
                            value={progressData.projects.completed}
                            total={progressData.projects.total}
                            icon={<FiBriefcase />}
                            color="bg-blue-500"
                            percentage={Math.round((progressData.projects.completed / progressData.projects.total) * 100) || 0}
                        />
                        <ProgressCard
                            title="Tasks Completed"
                            value={progressData.tasks.completed}
                            total={progressData.tasks.total}
                            icon={<FiCheckCircle />}
                            color="bg-green-500"
                            percentage={Math.round((progressData.tasks.completed / progressData.tasks.total) * 100) || 0}
                        />
                        <ProgressCard
                            title="Active Employees"
                            value={progressData.employees.active}
                            total={progressData.employees.total}
                            icon={<FiUsers />}
                            color="bg-purple-500"
                            percentage={100}
                        />
                        <ProgressCard
                            title="Revenue Growth"
                            value={"₹" + progressData.sales.total.toLocaleString()}
                            total="Target"
                            icon={<FiDollarSign />}
                            color="bg-orange-500"
                            percentage={75}
                        />
                    </div>

                    {/* Detailed Progress */}
                    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                        {/* Project Status */}
                        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
                            <h3 className="text-lg font-bold text-gray-800 mb-6">Project Status Breakdown</h3>
                            <div className="space-y-4">
                                <div>
                                    <div className="flex justify-between mb-2">
                                        <span className="text-sm font-medium text-gray-600">Completed</span>
                                        <span className="text-sm font-bold text-green-600">{progressData.projects.completed}</span>
                                    </div>
                                    <div className="w-full bg-gray-200 rounded-full h-3">
                                        <div
                                            className="bg-green-500 h-3 rounded-full"
                                            style={{ width: `${(progressData.projects.completed / progressData.projects.total) * 100}%` }}
                                        ></div>
                                    </div>
                                </div>
                                <div>
                                    <div className="flex justify-between mb-2">
                                        <span className="text-sm font-medium text-gray-600">In Progress</span>
                                        <span className="text-sm font-bold text-blue-600">{progressData.projects.inProgress}</span>
                                    </div>
                                    <div className="w-full bg-gray-200 rounded-full h-3">
                                        <div
                                            className="bg-blue-500 h-3 rounded-full"
                                            style={{ width: `${(progressData.projects.inProgress / progressData.projects.total) * 100}%` }}
                                        ></div>
                                    </div>
                                </div>
                                <div>
                                    <div className="flex justify-between mb-2">
                                        <span className="text-sm font-medium text-gray-600">Pending</span>
                                        <span className="text-sm font-bold text-orange-600">{progressData.projects.pending}</span>
                                    </div>
                                    <div className="w-full bg-gray-200 rounded-full h-3">
                                        <div
                                            className="bg-orange-500 h-3 rounded-full"
                                            style={{ width: `${(progressData.projects.pending / progressData.projects.total) * 100}%` }}
                                        ></div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        {/* Recent Milestones */}
                        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
                            <h3 className="text-lg font-bold text-gray-800 mb-6">Recent Milestones</h3>
                            <div className="space-y-4">
                                {[
                                    { title: 'Website Redesign Completed', date: '2 days ago', status: 'completed' },
                                    { title: 'New Client Onboarded', date: '5 days ago', status: 'completed' },
                                    { title: 'Q4 Sales Target Achieved', date: '1 week ago', status: 'completed' },
                                    { title: 'Team Expansion', date: '2 weeks ago', status: 'completed' }
                                ].map((milestone, index) => (
                                    <div key={index} className="flex items-start gap-3 p-3 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors">
                                        <div className="p-2 bg-green-100 rounded-lg">
                                            <FiCheckCircle className="text-green-600" />
                                        </div>
                                        <div className="flex-1">
                                            <h4 className="font-medium text-gray-800">{milestone.title}</h4>
                                            <p className="text-sm text-gray-500 flex items-center mt-1">
                                                <FiClock className="mr-1" /> {milestone.date}
                                            </p>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </div>
                    </div>

                    {/* Performance Chart Placeholder */}
                    <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
                        <h3 className="text-lg font-bold text-gray-800 mb-6">Monthly Performance Trend</h3>
                        <div className="h-64 flex items-center justify-center bg-gradient-to-br from-indigo-50 to-purple-50 rounded-lg">
                            <div className="text-center">
                                <FiTrendingUp className="text-6xl text-indigo-300 mx-auto mb-4" />
                                <p className="text-gray-500">Performance chart visualization</p>
                                <p className="text-sm text-gray-400 mt-2">Showing upward trend in all metrics</p>
                            </div>
                        </div>
                    </div>
                </>
            )}
        </div>
    );
};

export default Progress;
