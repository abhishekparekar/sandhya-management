import React from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import {
    FiHome, FiUsers, FiBriefcase, FiDollarSign, FiPhone,
    FiBox, FiFileText, FiAward, FiLogOut, FiSettings,
    FiTrendingUp, FiCheckCircle
} from 'react-icons/fi';
import { useAuth } from '../context/AuthContext';

const Sidebar = ({ isSidebarOpen, setIsSidebarOpen }) => {
    const { logout } = useAuth();
    const location = useLocation();
    const navigate = useNavigate();

    const handleLogout = async () => {
        try {
            await logout();
            navigate('/login');
        } catch (error) {
            console.error("Failed to log out", error);
        }
    };

    const menuItems = [
        { path: '/', label: 'Dashboard', icon: <FiHome /> },
        { path: '/projects', label: 'Projects', icon: <FiBriefcase /> },
        { path: '/sales', label: 'Sales', icon: <FiDollarSign /> },
        { path: '/telecalling', label: 'Telecalling', icon: <FiPhone /> },
        { path: '/expenses', label: 'Expenses', icon: <FiFileText /> },
        { path: '/inventory', label: 'Inventory', icon: <FiBox /> },
        { path: '/employees', label: 'Employees', icon: <FiUsers /> },
        { path: '/internship', label: 'Internship', icon: <FiUsers /> },
        { path: '/certificates', label: 'Certificates', icon: <FiAward /> },
        { path: '/id-cards', label: 'ID Cards', icon: <FiUsers /> },
        { path: '/documents', label: 'Documents', icon: <FiFileText /> },
        { path: '/progress', label: 'Progress', icon: <FiTrendingUp /> },
        { path: '/tasks', label: 'Tasks', icon: <FiCheckCircle /> },
        { path: '/reports', label: 'Reports', icon: <FiFileText /> },
        { path: '/settings', label: 'Settings', icon: <FiSettings /> },
    ];

    return (
        <>
            {/* Mobile Overlay */}
            {isSidebarOpen && (
                <div
                    className="fixed inset-0 bg-black/50 z-20 md:hidden"
                    onClick={() => setIsSidebarOpen(false)}
                />
            )}

            <aside
                className={`fixed md:relative bg-gradient-to-b from-[#1B5E7E] to-[#164A5E] text-white transition-all duration-300 ease-in-out h-full z-30 ${isSidebarOpen ? 'w-64 translate-x-0' : 'w-0 md:w-20 -translate-x-full md:translate-x-0'
                    } flex flex-col shadow-xl`}
            >
                {/* Logo Section */}
                <div className={`p-4 flex items-center justify-center border-b border-white/10 transition-all duration-300 ${isSidebarOpen ? 'h-28' : 'md:h-20 h-28'
                    }`}>
                    <div className={`transition-all duration-300 ${!isSidebarOpen && 'md:hidden'}`}>
                        <img
                            src="/logo.jpg"
                            alt="Sandhya Softtech"
                            className="w-full h-auto max-w-[200px] object-contain"
                        />
                    </div>
                    {!isSidebarOpen && (
                        <div className="hidden md:block">
                            <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-[#F47920] to-[#FF8C42] flex items-center justify-center font-bold text-white text-2xl shadow-lg">
                                S
                            </div>
                        </div>
                    )}
                </div>

                <nav className="flex-1 overflow-y-auto py-4 overflow-x-hidden">
                    <ul className="space-y-1 px-2">
                        {menuItems.map((item) => (
                            <li key={item.path}>
                                <Link
                                    to={item.path}
                                    className={`flex items-center px-4 py-3 rounded-lg transition-all duration-200 group relative ${location.pathname === item.path
                                            ? 'bg-[#F47920] text-white shadow-lg shadow-orange-500/30'
                                            : 'text-white/80 hover:bg-white/10 hover:text-white'
                                        }`}
                                >
                                    <span className="text-xl min-w-[20px]">{item.icon}</span>
                                    <span className={`ml-3 font-medium whitespace-nowrap transition-all duration-300 ${!isSidebarOpen ? 'md:opacity-0 md:w-0 overflow-hidden' : 'opacity-100'
                                        }`}>
                                        {item.label}
                                    </span>

                                    {/* Tooltip for collapsed state on desktop */}
                                    {!isSidebarOpen && (
                                        <div className="hidden md:block absolute left-full top-1/2 -translate-y-1/2 rounded-md px-2 py-1 ml-4 bg-[#1B5E7E] text-white text-sm invisible opacity-0 -translate-x-3 transition-all group-hover:visible group-hover:opacity-100 group-hover:translate-x-0 whitespace-nowrap z-50 shadow-lg border border-white/20">
                                            {item.label}
                                        </div>
                                    )}
                                </Link>
                            </li>
                        ))}
                    </ul>
                </nav>

                <div className="p-4 border-t border-white/10">
                    <button
                        onClick={handleLogout}
                        className={`flex items-center w-full px-4 py-3 rounded-lg text-red-300 hover:bg-red-900/30 hover:text-red-100 transition-colors group relative ${!isSidebarOpen ? 'justify-center' : ''
                            }`}
                    >
                        <FiLogOut className="text-xl min-w-[20px]" />
                        <span className={`ml-3 font-medium whitespace-nowrap transition-all duration-300 ${!isSidebarOpen ? 'md:opacity-0 md:w-0 overflow-hidden' : 'opacity-100'
                            }`}>
                            Logout
                        </span>
                        {!isSidebarOpen && (
                            <div className="hidden md:block absolute left-full top-1/2 -translate-y-1/2 rounded-md px-2 py-1 ml-4 bg-red-900 text-red-100 text-sm invisible opacity-0 -translate-x-3 transition-all group-hover:visible group-hover:opacity-100 group-hover:translate-x-0 whitespace-nowrap z-50 shadow-lg">
                                Logout
                            </div>
                        )}
                    </button>
                </div>
            </aside>
        </>
    );
};

export default Sidebar;
