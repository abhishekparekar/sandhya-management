import React, { useState, useEffect } from 'react';
import { db } from '../services/firebase';
import { collection, getDocs, query, where } from 'firebase/firestore';
import { FiTrendingUp, FiTrendingDown, FiDollarSign, FiUsers, FiBriefcase } from 'react-icons/fi';

const Reports = () => {
    const [stats, setStats] = useState({
        totalSales: 0,
        totalExpenses: 0,
        profit: 0,
        totalProjects: 0,
        completedProjects: 0,
        totalEmployees: 0
    });
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const fetchStats = async () => {
            setLoading(true);
            try {
                // Fetch Sales
                const salesSnap = await getDocs(collection(db, 'sales'));
                const totalSales = salesSnap.docs.reduce((acc, doc) => acc + Number(doc.data().amount || 0), 0);

                // Fetch Expenses
                const expensesSnap = await getDocs(collection(db, 'expenses'));
                const totalExpenses = expensesSnap.docs.reduce((acc, doc) => acc + Number(doc.data().amount || 0), 0);

                // Fetch Projects
                const projectsSnap = await getDocs(collection(db, 'projects'));
                const totalProjects = projectsSnap.size;
                const completedProjects = projectsSnap.docs.filter(doc => doc.data().status === 'Completed').length;

                // Fetch Employees
                const employeesSnap = await getDocs(collection(db, 'employees'));
                const totalEmployees = employeesSnap.size;

                setStats({
                    totalSales,
                    totalExpenses,
                    profit: totalSales - totalExpenses,
                    totalProjects,
                    completedProjects,
                    totalEmployees
                });
            } catch (error) {
                console.error("Error fetching stats: ", error);
            } finally {
                setLoading(false);
            }
        };

        fetchStats();
    }, []);

    const profitMargin = stats.totalSales > 0 ? ((stats.profit / stats.totalSales) * 100).toFixed(1) : 0;

    return (
        <div className="space-y-6">
            <h1 className="text-2xl font-bold text-gray-800">Reports & Analytics</h1>

            {loading ? (
                <div className="flex justify-center py-12">
                    <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600"></div>
                </div>
            ) : (
                <>
                    {/* Financial Overview */}
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
                            <div className="flex items-center justify-between mb-4">
                                <h3 className="text-gray-500 font-medium">Total Revenue</h3>
                                <div className="p-2 bg-green-100 text-green-600 rounded-lg"><FiDollarSign /></div>
                            </div>
                            <p className="text-3xl font-bold text-gray-800">₹ {stats.totalSales.toLocaleString()}</p>
                            <p className="text-sm text-green-600 mt-2 flex items-center"><FiTrendingUp className="mr-1" /> Income</p>
                        </div>

                        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
                            <div className="flex items-center justify-between mb-4">
                                <h3 className="text-gray-500 font-medium">Total Expenses</h3>
                                <div className="p-2 bg-red-100 text-red-600 rounded-lg"><FiTrendingDown /></div>
                            </div>
                            <p className="text-3xl font-bold text-gray-800">₹ {stats.totalExpenses.toLocaleString()}</p>
                            <p className="text-sm text-red-600 mt-2 flex items-center"><FiTrendingDown className="mr-1" /> Outflow</p>
                        </div>

                        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
                            <div className="flex items-center justify-between mb-4">
                                <h3 className="text-gray-500 font-medium">Net Profit</h3>
                                <div className={`p-2 rounded-lg ${stats.profit >= 0 ? 'bg-indigo-100 text-indigo-600' : 'bg-orange-100 text-orange-600'}`}>
                                    <FiTrendingUp />
                                </div>
                            </div>
                            <p className={`text-3xl font-bold ${stats.profit >= 0 ? 'text-indigo-600' : 'text-orange-600'}`}>
                                ₹ {stats.profit.toLocaleString()}
                            </p>
                            <p className="text-sm text-gray-500 mt-2">Margin: {profitMargin}%</p>
                        </div>
                    </div>

                    {/* Operational Stats */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
                            <h3 className="text-lg font-bold text-gray-800 mb-6">Project Status</h3>
                            <div className="flex items-center justify-around">
                                <div className="text-center">
                                    <div className="text-4xl font-bold text-indigo-600 mb-2">{stats.totalProjects}</div>
                                    <div className="text-sm text-gray-500">Total Projects</div>
                                </div>
                                <div className="h-12 w-px bg-gray-200"></div>
                                <div className="text-center">
                                    <div className="text-4xl font-bold text-green-600 mb-2">{stats.completedProjects}</div>
                                    <div className="text-sm text-gray-500">Completed</div>
                                </div>
                                <div className="h-12 w-px bg-gray-200"></div>
                                <div className="text-center">
                                    <div className="text-4xl font-bold text-yellow-600 mb-2">{stats.totalProjects - stats.completedProjects}</div>
                                    <div className="text-sm text-gray-500">Active</div>
                                </div>
                            </div>
                        </div>

                        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
                            <h3 className="text-lg font-bold text-gray-800 mb-6">Workforce</h3>
                            <div className="flex items-center gap-6">
                                <div className="p-4 bg-purple-100 text-purple-600 rounded-full text-2xl">
                                    <FiUsers />
                                </div>
                                <div>
                                    <p className="text-4xl font-bold text-gray-800">{stats.totalEmployees}</p>
                                    <p className="text-gray-500">Active Employees</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </>
            )}
        </div>
    );
};

export default Reports;
