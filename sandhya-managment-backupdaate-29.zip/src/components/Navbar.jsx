import React from 'react';
import { useAuth } from '../context/AuthContext';
import { useLocation } from 'react-router-dom';
import { FiMenu } from 'react-icons/fi';

const Navbar = ({ isSidebarOpen, setIsSidebarOpen }) => {
    const { currentUser, userRole } = useAuth();
    const location = useLocation();

    const getPageTitle = (path) => {
        const pathName = path.split('/')[1];
        if (!pathName) return 'Dashboard';
        return pathName.charAt(0).toUpperCase() + pathName.slice(1).replace('-', ' ');
    };

    return (
        <header className="h-16 bg-white shadow-sm flex items-center justify-between px-6 z-10">
            <div className="flex items-center gap-4">
                <button
                    onClick={() => setIsSidebarOpen(!isSidebarOpen)}
                    className="md:hidden p-2 text-gray-600 hover:bg-gray-100 rounded-lg"
                >
                    <FiMenu className="text-xl" />
                </button>
                <h2 className="text-xl font-semibold text-gray-800">
                    {getPageTitle(location.pathname)}
                </h2>
            </div>
            <div className="flex items-center space-x-4">
                <div className="text-right hidden sm:block">
                    <p className="text-sm font-medium text-gray-900">{currentUser?.email}</p>
                    <p className="text-xs text-gray-500 capitalize">{userRole}</p>
                </div>
                <div className="h-10 w-10 rounded-full bg-indigo-100 flex items-center justify-center text-indigo-600 font-bold border border-indigo-200">
                    {currentUser?.email?.charAt(0).toUpperCase()}
                </div>
            </div>
        </header>
    );
};

export default Navbar;
